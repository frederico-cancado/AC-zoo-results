import OAI.SetTheory.PartitionConsistency.Forcing.Diagrams

/-!
Independent audit of the cyclic three-copy overlap used in the OEP argument.
This file checks the actual pinned `OverlapPrescription.Valid` definition.
It does not formalize symmetric forcing or the final failure of BPI.
-/

namespace SixCycleAudit

open OAI.PartitionConsistency.DiagramForcing

universe u
variable {M : Type u} [LeftCancelMonoid M]

def cyclicPrescription (a h : M) : OverlapPrescription M 3 where
  start i j := match i.val, j.val with
    | 0, 1 => some (h, a)
    | 1, 2 => some (h, a)
    | 2, 0 => some (h, a)
    | 1, 0 => some (a, h)
    | 2, 1 => some (a, h)
    | 0, 2 => some (a, h)
    | _, _ => none

abbrev Edge (p q x y : M) : Prop := ∃ t, x = p * t ∧ y = q * t

theorem edge_symm {p q x y : M} (H : Edge p q x y) : Edge q p y x := by
  rcases H with ⟨t, hx, hy⟩
  exact ⟨t, hy, hx⟩

theorem edge_back {p q x y z : M}
    (H : Edge p q x y) (K : Edge q p y z) : x = z := by
  rcases H with ⟨t, hx, hy⟩
  rcases K with ⟨s, hy', hz⟩
  have ht : t = s := mul_left_cancel (hy.symm.trans hy')
  subst s
  exact hx.trans hz.symm

theorem edge_turn {a h e : M} (ha : a * e = e) (hh : h * e = e)
    (cross : ∀ x y : M, a * x = h * y → ∃ z, x = e * z ∧ y = e * z)
    {x y z : M} (H : Edge h a x y) (K : Edge h a y z) : Edge a h x z := by
  rcases H with ⟨t, hx, hy⟩
  rcases K with ⟨s, hy', hz⟩
  obtain ⟨v, ht, hs⟩ := cross t s (hy.symm.trans hy')
  refine ⟨e * v, ?_, ?_⟩
  · simpa only [ht, ← mul_assoc, ha, hh] using hx
  · simpa only [hs, ← mul_assoc, ha, hh] using hz

theorem cyclicPrescription_valid {a h e : M}
    (ha : a * e = e) (hh : h * e = e)
    (cross : ∀ x y : M, a * x = h * y → ∃ z, x = e * z ∧ y = e * z) :
    (cyclicPrescription a h).Valid := by
  have cross' : ∀ x y : M, h * x = a * y → ∃ z, x = e * z ∧ y = e * z := by
    intro x y H
    obtain ⟨z, hy, hx⟩ := cross y x H.symm
    exact ⟨z, hx, hy⟩
  refine ⟨?_, ?_, ?_⟩
  · rintro ⟨i, x⟩
    simp [OverlapPrescription.Rel]
  · rintro ⟨i, x⟩ ⟨j, y⟩ H
    fin_cases i <;> fin_cases j <;>
      simp only [OverlapPrescription.Rel, cyclicPrescription, Fin.mk.injEq] at H ⊢ <;>
      simp_all only [↓reduceIte, Nat.reduceEqDiff] <;>
      first | exact H.symm | exact edge_symm H
  · rintro ⟨i, x⟩ ⟨j, y⟩ ⟨k, z⟩ H K
    fin_cases i <;> fin_cases j <;> fin_cases k <;>
      simp [OverlapPrescription.Rel, cyclicPrescription] at H K ⊢
    all_goals first
      | subst_vars; assumption
      | subst_vars; rfl
      | exact edge_back H K
      | exact edge_turn ha hh cross H K
      | exact edge_turn hh ha cross' H K


/-- The parameter-intersection hypothesis used above follows from the usual
principal-right-ideal intersection in the monoid theorem. -/
theorem cross_of_range_inter {a h e : M}
    (ha : a * e = e) (hh : h * e = e)
    (inter : Set.range (fun x : M => a * x) ∩ Set.range (fun x : M => h * x) =
      Set.range (fun x : M => e * x)) :
    ∀ x y : M, a * x = h * y → ∃ z, x = e * z ∧ y = e * z := by
  intro x y H
  have HR : a * x ∈ Set.range (fun z : M => e * z) := by
    rw [← inter]
    exact ⟨⟨x, rfl⟩, ⟨y, H.symm⟩⟩
  obtain ⟨z, hz⟩ := HR
  refine ⟨z, mul_left_cancel (a := a) ?_, mul_left_cancel (a := h) ?_⟩
  · calc a * x = e * z := hz.symm
         _ = a * (e * z) := by rw [← mul_assoc, ha]
  · calc h * y = e * z := H.symm.trans hz.symm
         _ = h * (e * z) := by rw [← mul_assoc, hh]

/-- The critical theorem with precisely the geometric cone hypotheses. -/
theorem cyclicPrescription_valid_of_cones {a h e : M}
    (ha : a * e = e) (hh : h * e = e)
    (inter : Set.range (fun x : M => a * x) ∩ Set.range (fun x : M => h * x) =
      Set.range (fun x : M => e * x)) :
    (cyclicPrescription a h).Valid :=
  cyclicPrescription_valid ha hh (cross_of_range_inter ha hh inter)

/-- Each root point is identified with the SAME root point in all copies. -/
theorem root_related {a h e : M} (ha : a * e = e) (hh : h * e = e)
    (i j : Fin 3) (x : M) :
    (cyclicPrescription a h).Rel (i, e * x) (j, e * x) := by
  fin_cases i <;> fin_cases j <;>
    simp [OverlapPrescription.Rel, cyclicPrescription]
  all_goals exact ⟨e * x, by simp [← mul_assoc, ha, hh], by simp [← mul_assoc, ha, hh]⟩

/-- Passing through the three copies adds no new identifications on the root. -/
theorem root_exact {a h e : M}
    (ha : a * e = e) (hh : h * e = e)
    (cross : ∀ x y : M, a * x = h * y → ∃ z, x = e * z ∧ y = e * z)
    (i j : Fin 3) (x y : M) :
    (cyclicPrescription a h).Rel (i, e * x) (j, e * y) ↔ x = y := by
  constructor
  · intro H
    have K := (cyclicPrescription_valid ha hh cross).trans H (root_related ha hh j i y)
    exact mul_left_cancel ((OverlapPrescription.rel_same_copy _ i _ _).mp K)
  · rintro rfl
    exact root_related ha hh i j x

/-- No two distinct elements of one copy are identified. This is the exact
source relation, already proved transitive, rather than an equivalence closure. -/
theorem same_copy_exact (a h : M) (i : Fin 3) (x y : M) :
    (cyclicPrescription a h).Rel (i, x) (i, y) ↔ x = y :=
  OverlapPrescription.rel_same_copy _ i x y

/-- Two consecutive forward edges can meet only at one common root point. -/
theorem two_edges_force_root {a h e : M}
    (ha : a * e = e) (hh : h * e = e)
    (cross : ∀ x y : M, a * x = h * y → ∃ z, x = e * z ∧ y = e * z)
    {x y z : M} (H : Edge h a x y) (K : Edge h a y z) :
    ∃ v, x = e * v ∧ y = e * v ∧ z = e * v := by
  rcases H with ⟨t, hx, hy⟩
  rcases K with ⟨s, hy', hz⟩
  obtain ⟨v, ht, hs⟩ := cross t s (hy.symm.trans hy')
  refine ⟨v, ?_, ?_, ?_⟩
  · simpa only [ht, ← mul_assoc, hh] using hx
  · simpa only [ht, ← mul_assoc, ha] using hy
  · simpa only [hs, ← mul_assoc, ha] using hz

/-- Exact realizations follow from the source finite-merger axiom, with no
additional transitive closure or additional overlap hypothesis. -/
theorem exact_merger {a h e : M}
    (ha : a * e = e) (hh : h * e = e)
    (inter : Set.range (fun x : M => a * x) ∩ Set.range (fun x : M => h * x) =
      Set.range (fun x : M => e * x)) (merger : HasFiniteMergers M) :
    ∃ l : Fin 3 → M, ∀ z w : Fin 3 × M,
      l z.1 * z.2 = l w.1 * w.2 ↔ (cyclicPrescription a h).Rel z w :=
  merger 3 (cyclicPrescription a h) (cyclicPrescription_valid_of_cones ha hh inter)

variable {V : Type*}

/-- One-bit-column compatibility. The outgoing h-petal is silent away from
the common root; on the root both copies read the identical original entry. -/
theorem silent_edge_compatible {a h e : M}
    (ha : a * e = e) (hh : h * e = e) (c : M → Option V)
    (silent : ∀ x : M, (¬ ∃ z : M, h * x = e * z) → c (h * x) = none)
    {x y : M} {v w : V} (H : Edge h a x y)
    (hv : c x = some v) (hw : c y = some w) : v = w := by
  rcases H with ⟨t, hx, hy⟩
  by_cases HR : ∃ z : M, h * t = e * z
  · obtain ⟨z, hz⟩ := HR
    have ht : t = e * z := mul_left_cancel (a := h) (by simpa only [← mul_assoc, hh] using hz)
    have hxy : x = y := by
      rw [hx, hy, ht, ← mul_assoc, ← mul_assoc, ha, hh]
    exact Option.some.inj (hv.symm.trans ((congrArg c hxy).trans hw))
  · have hn := silent t HR
    rw [← hx, hv] at hn
    contradiction

/-- Copied assignments cannot disagree at any identified chart point.
Apply independently to each Cohen bit-column. -/
theorem cyclic_assignments_compatible {a h e : M}
    (ha : a * e = e) (hh : h * e = e) (c : M → Option V)
    (silent : ∀ x : M, (¬ ∃ z : M, h * x = e * z) → c (h * x) = none)
    {i j : Fin 3} {x y : M} {v w : V}
    (H : (cyclicPrescription a h).Rel (i, x) (j, y))
    (hv : c x = some v) (hw : c y = some w) : v = w := by
  fin_cases i <;> fin_cases j <;>
    simp [OverlapPrescription.Rel, cyclicPrescription] at H
  all_goals first
    | exact Option.some.inj (hv.symm.trans ((congrArg c H).trans hw))
    | exact silent_edge_compatible ha hh c silent H hv hw
    | exact (silent_edge_compatible ha hh c silent (edge_symm H) hw hv).symm

/-- The compatibility statement after any exact chart placement into an
index set. No injectivity or ambient-order inference is implicit here. -/
theorem realized_assignments_compatible {I : Type*} {a h e : M}
    (ha : a * e = e) (hh : h * e = e) (c : M → Option V)
    (silent : ∀ x : M, (¬ ∃ z : M, h * x = e * z) → c (h * x) = none)
    (r : Fin 3 → M → I)
    (exactOverlap : ∀ (i j : Fin 3) (x y : M),
      r i x = r j y ↔ (cyclicPrescription a h).Rel (i, x) (j, y))
    {i j : Fin 3} {x y : M} {v w : V}
    (H : r i x = r j y) (hv : c x = some v) (hw : c y = some w) : v = w :=
  cyclic_assignments_compatible ha hh c silent ((exactOverlap i j x y).mp H) hv hw

#print axioms cyclicPrescription_valid
#print axioms cyclicPrescription_valid_of_cones
#print axioms root_exact
#print axioms same_copy_exact
#print axioms two_edges_force_root
#print axioms exact_merger
#print axioms cyclic_assignments_compatible
#print axioms realized_assignments_compatible

end SixCycleAudit
