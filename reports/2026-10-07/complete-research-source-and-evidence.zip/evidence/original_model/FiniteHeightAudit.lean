import OAI.SetTheory.PartitionConsistency.Algebra.DiagramOrder

/-! Quantitative finite obstruction used in the new finite-order forcing audit.
This checks the actual pinned source HeightCost and HasConditionalJoins.
It does not formalize the Ramsey argument or symmetric forcing transfer. -/
namespace FiniteHeightAudit
open OAI.PartitionConsistency.DiagramOrder
universe u
variable {X : Type u} [PartialOrder X]

theorem prefix_lub (J : HasConditionalJoins X) (a : ℕ → X) (n : ℕ)
    (cap : X) (bounded : ∀ i, i ≤ n → a i ≤ cap) :
    ∃ v : X, (∀ i, i ≤ n → a i ≤ v) ∧
      ∀ z : X, (∀ i, i ≤ n → a i ≤ z) → v ≤ z := by
  induction n with
  | zero =>
    refine ⟨a 0, ?_, ?_⟩
    · intro i hi
      have : i = 0 := by omega
      subst i
      exact le_rfl
    · intro z hz
      exact hz 0 (by omega)
  | succ n ih =>
    obtain ⟨v, hv, hl⟩ := ih (fun i hi => bounded i (by omega))
    have hvc : v ≤ cap := hl cap (fun i hi => bounded i (by omega))
    obtain ⟨w, hw⟩ := J v (a (n+1)) cap hvc (bounded (n+1) (by omega))
    have hvw : v ≤ w := hw.1 (by simp)
    have haw : a (n+1) ≤ w := hw.1 (by simp)
    refine ⟨w, ?_, ?_⟩
    · intro i hi
      by_cases hin : i ≤ n
      · exact (hv i hin).trans hvw
      · have heq : i = n+1 := by omega
        simpa [heq] using haw
    · intro z hz
      apply hw.2
      intro x hx
      simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hx
      rcases hx with rfl | rfl
      · exact hl z (fun i hi => hz i (by omega))
      · exact hz (n+1) (by omega)

theorem no_triangular_array
    (H : HeightCost X) (J : HasConditionalJoins X)
    (m : ℕ) (c : ℝ) (budget : 1 ≤ (m : ℝ) * c)
    (a b : ℕ → X)
    (cost : ∀ i, i ≤ m → c ≤ H.cost (a i))
    (miss : ∀ i, i ≤ m → ¬ a i ≤ b i)
    (cross : ∀ i j, i < j → j ≤ m+1 → a i ≤ b j) : False := by
  classical
  have ex : ∀ n : ℕ, ∃ v : X, n ≤ m →
      (∀ i, i ≤ n → a i ≤ v) ∧
      ∀ z : X, (∀ i, i ≤ n → a i ≤ z) → v ≤ z := by
    intro n
    by_cases hn : n ≤ m
    · obtain ⟨v, hv⟩ := prefix_lub J a n (b (m+1))
        (fun i hi => cross i (m+1) (by omega) (by omega))
      exact ⟨v, fun _ => hv⟩
    · exact ⟨a 0, fun h => False.elim (hn h)⟩
  choose v hv using ex
  have lower : ∀ n : ℕ, n ≤ m → (n : ℝ) * c < H.height (v n) := by
    intro n
    induction n with
    | zero =>
      intro _
      simpa using H.height_pos (v 0)
    | succ n ih =>
      intro hn
      have hn' : n ≤ m := by omega
      have hprev := hv n hn'
      have hcurr := hv (n+1) hn
      have hvb : v n ≤ b (n+1) :=
        hprev.2 (b (n+1)) (fun i hi => cross i (n+1) (by omega) (by omega))
      have hmiss : ¬ a (n+1) ≤ v n :=
        fun h => miss (n+1) hn (h.trans hvb)
      have hmono : v n ≤ v (n+1) :=
        hprev.2 (v (n+1)) (fun i hi => hcurr.1 i (by omega))
      have ha : a (n+1) ≤ v (n+1) := hcurr.1 (n+1) (by omega)
      have hstrict : v n < v (n+1) :=
        lt_of_le_not_ge hmono (fun h => hmiss (ha.trans h))
      have hgap := H.point_margin hstrict ha hmiss
      have hc := cost (n+1) hn
      have hp := ih hn'
      push_cast
      nlinarith
  have hlast := lower m le_rfl
  have hupper := H.height_lt_one (v m)
  linarith

theorem no_unit_triangular_array
    (H : HeightCost X) (J : HasConditionalJoins X)
    (m : ℕ) (hm : 0 < m) (a b : ℕ → X)
    (cost : ∀ i, i ≤ m → (1 : ℝ) / m ≤ H.cost (a i))
    (miss : ∀ i, i ≤ m → ¬ a i ≤ b i)
    (cross : ∀ i j, i < j → j ≤ m+1 → a i ≤ b j) : False := by
  apply no_triangular_array H J m ((1 : ℝ)/m) ?_ a b cost miss cross
  have hmr : (m : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hm)
  simp [hmr]

#print axioms prefix_lub
#print axioms no_triangular_array
#print axioms no_unit_triangular_array
end FiniteHeightAudit
